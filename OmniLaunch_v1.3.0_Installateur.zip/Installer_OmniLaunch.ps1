# Assistant de deploiement moderne OmniLaunch Gamer Edition
param(
    [switch]$Silent = $false
)

$ErrorActionPreference = "Stop"
$TotalStopwatch = [System.Diagnostics.Stopwatch]::StartNew()

$AppName = "OmniLaunch"
$AppVersion = "1.2.9"
$AppPublisher = "baffert"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SetupFilesDir = Join-Path $ScriptDir "Setup_Files"

# Detect dynamic version if VERSION.txt exists
$VerFile = Join-Path $SetupFilesDir "VERSION.txt"
if (Test-Path $VerFile) {
    $verText = (Get-Content $VerFile -Raw).Trim()
    if ($verText -match '([0-9]+\.[0-9]+\.[0-9]+)') {
        $AppVersion = $matches[1]
    }
}

if (-not (Test-Path $SetupFilesDir)) {
    Write-Host "[ERREUR] Le dossier Setup_Files est introuvable." -ForegroundColor Red
    Write-Host "Veuillez d'abord extraire l'archive ZIP complete." -ForegroundColor Yellow
    exit 1
}

$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\OmniLaunch"
$ExeTarget = Join-Path $InstallDir "OmniLaunch.exe"
$IcoTarget = Join-Path $InstallDir "app.ico"
$UninstBat = Join-Path $InstallDir "Desinstaller_OmniLaunch.bat"

Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "     INSTALLATION DE OMNILAUNCH GAMER EDITION v$AppVersion     " -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Dossier d'installation : $InstallDir" -ForegroundColor Gray

# 1. Fermer toute instance precedente
Get-Process -Name "OmniLaunch" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

# Mesure du volume a copier
$measure = Get-ChildItem -Path $SetupFilesDir -Recurse -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum
$totalBytes = if ($measure) { $measure.Sum } else { 0 }
$totalMB = [math]::Round($totalBytes / 1MB, 2)

# 2. Deploiement des fichiers avec chronometrage
Write-Host "[1/4] Copie ultra-rapide des fichiers ($totalMB Mo)..." -ForegroundColor Yellow
$copyWatch = [System.Diagnostics.Stopwatch]::StartNew()
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
}
Copy-Item -Path "$SetupFilesDir\*" -Destination $InstallDir -Recurse -Force
$copyWatch.Stop()
$copyElapsedSec = [math]::Max(0.01, $copyWatch.Elapsed.TotalSeconds)
$speedMBps = [math]::Round($totalMB / $copyElapsedSec, 1)

# 3. Creation des raccourcis
Write-Host "[2/4] Creation des raccourcis Bureau et Menu Demarrer..." -ForegroundColor Yellow
$WshShell = New-Object -ComObject WScript.Shell

# Raccourci Bureau
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$DesktopShortcutPath = Join-Path $DesktopPath "OmniLaunch.lnk"
$Shortcut = $WshShell.CreateShortcut($DesktopShortcutPath)
$Shortcut.TargetPath = $ExeTarget
$Shortcut.WorkingDirectory = $InstallDir
if (Test-Path $IcoTarget) {
    $Shortcut.IconLocation = "$IcoTarget,0"
}
$Shortcut.Description = "OmniLaunch - Universal Game Launcher"
$Shortcut.Save()

# Raccourci Menu Demarrer
$StartMenuPath = [Environment]::GetFolderPath("Programs")
$StartShortcutPath = Join-Path $StartMenuPath "OmniLaunch.lnk"
$StartShortcut = $WshShell.CreateShortcut($StartShortcutPath)
$StartShortcut.TargetPath = $ExeTarget
$StartShortcut.WorkingDirectory = $InstallDir
if (Test-Path $IcoTarget) {
    $StartShortcut.IconLocation = "$IcoTarget,0"
}
$Shortcut.Description = "OmniLaunch - Universal Game Launcher"
$StartShortcut.Save()

# 4. Inscription dans Windows (Ajout/Suppression de programmes)
Write-Host "[3/4] Enregistrement dans Windows (Applications & Fonctionnalites)..." -ForegroundColor Yellow
$RegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmniLaunch"
if (-not (Test-Path $RegPath)) {
    New-Item -Path $RegPath -Force | Out-Null
}

$TotalStopwatch.Stop()
$totalSec = [math]::Round($TotalStopwatch.Elapsed.TotalSeconds, 2)

Set-ItemProperty -Path $RegPath -Name "DisplayName" -Value "OmniLaunch Gamer Edition"
Set-ItemProperty -Path $RegPath -Name "DisplayVersion" -Value $AppVersion
Set-ItemProperty -Path $RegPath -Name "Publisher" -Value $AppPublisher
Set-ItemProperty -Path $RegPath -Name "InstallLocation" -Value $InstallDir
Set-ItemProperty -Path $RegPath -Name "DisplayIcon" -Value "$ExeTarget,0"
Set-ItemProperty -Path $RegPath -Name "UninstallString" -Value "`"$UninstBat`""
Set-ItemProperty -Path $RegPath -Name "NoModify" -Value 1
Set-ItemProperty -Path $RegPath -Name "NoRepair" -Value 1
Set-ItemProperty -Path $RegPath -Name "InstallDate" -Value (Get-Date -Format "yyyyMMdd")
Set-ItemProperty -Path $RegPath -Name "InstallDurationSeconds" -Value $totalSec
Set-ItemProperty -Path $RegPath -Name "InstallSpeedMBps" -Value $speedMBps

Write-Host "[4/4] Installation terminee avec succes !" -ForegroundColor Green
Write-Host ""
Write-Host "==============================================================" -ForegroundColor Green
Write-Host "     OMNILAUNCH GAMER EDITION EST PRET A ETRE UTILISE !       " -ForegroundColor Green
Write-Host "==============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  ⏱️  Temps d'installation : $totalSec s (Copie : $speedMBps Mo/s)" -ForegroundColor Cyan
Write-Host "  📦  Taille de l'application : $totalMB Mo" -ForegroundColor Cyan
Write-Host ""

if (-not $Silent) {
    $choice = Read-Host "Souhaitez-vous lancer OmniLaunch maintenant ? (O/N) [O]"
    if ($choice -ne "N" -and $choice -ne "n") {
        Start-Process -FilePath $ExeTarget -WorkingDirectory $InstallDir
    }
}
