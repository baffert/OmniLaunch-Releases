@echo off
setlocal
cd /d "%~dp0"
title Assistant d'Installation OmniLaunch Gamer Edition v1.2.9 (Build 41)

:: Verification de l'extraction de l'archive ZIP
if not exist "%~dp0Setup_Files" (
    cls
    echo ====================================================================
    echo   ATTENTION : VOUS DEVEZ EXTRAIRE L'ARCHIVE ZIP AVANT D'INSTALLER !
    echo ====================================================================
    echo.
    echo   Il semble que vous ayez ouvert ce fichier directement dans le ZIP.
    echo.
    echo   Pour reussir l'installation :
    echo   1. Faites un clic droit sur l'archive ZIP
    echo   2. Cliquez sur 'Extraire tout' puis sur 'Extraire'
    echo   3. Ouvrez le dossier extrait et relancez 'Installer_OmniLaunch.bat'
    echo.
    echo ====================================================================
    pause
    exit /b 1
)

echo [OK] Lancement de l'assistant d'installation OmniLaunch...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Installer_OmniLaunch.ps1" %*
if %errorlevel% neq 0 (
    echo.
    echo [INFO] Fin de l'assistant d'installation.
    pause
)
exit /b %errorlevel%
