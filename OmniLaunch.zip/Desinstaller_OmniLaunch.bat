@echo off
setlocal
chcp 1252 >nul 2>&1
title Desinstallation d'OmniLaunch
echo ==============================================================
echo             DESINSTALLATION D'OMNILAUNCH GAMER EDITION
echo ==============================================================
echo.

set "INSTALL_DIR=%~dp0"
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"

:: Protection du dossier source
for %%I in ("%INSTALL_DIR%") do set "LEAF_DIR=%%~nxI"
if /i "%LEAF_DIR%"=="OmniLaunch_Client" (
    echo [SECURITE] Ce script est execute depuis le dossier portable "%LEAF_DIR%".
    echo            La suppression du dossier source est bloquee par precaution.
    echo            Seuls les raccourcis du Bureau et du Menu Demarrer seront retires.
)

set /p CONFIRM="Voulez-vous supprimer OmniLaunch et ses raccourcis (O/N) ? [O] : "
if /i "%CONFIRM%"=="N" (
    echo [INFO] Desinstallation annulee.
    pause
    exit /b 0
)

echo.
echo [1/3] Fermeture des processus OmniLaunch...
taskkill /f /im OmniLaunch.exe >nul 2>&1

echo [2/3] Suppression des raccourcis Bureau et Menu Demarrer...
del /f /q "%USERPROFILE%\Desktop\OmniLaunch.lnk" >nul 2>&1
del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\OmniLaunch.lnk" >nul 2>&1
del /f /q "%PUBLIC%\Desktop\OmniLaunch.lnk" >nul 2>&1

echo [3/3] Nettoyage des donnees...
if /i not "%LEAF_DIR%"=="OmniLaunch_Client" (
    echo Suppression des fichiers de programme...
    cd ..
    rmdir /s /q "%INSTALL_DIR%" >nul 2>&1
)

echo.
echo ==============================================================
echo  [SUCCES] OmniLaunch a ete desinstalle avec succes.
echo ==============================================================
echo.
pause
exit /b 0
