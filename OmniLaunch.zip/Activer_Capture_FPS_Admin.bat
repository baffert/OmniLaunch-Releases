@echo off
setlocal
title Activation Capture Materielle PresentMon (Zero UAC)
echo ==============================================================
echo        ACTIVATION DU COMPTEUR DE FPS HAUTE PRECISION        
echo ==============================================================
echo.
echo Cette operation ajoute votre compte au groupe Windows :
echo "Utilisateurs du journal de performances"
echo pour permettre a Intel PresentMon de mesurer vos FPS reels
echo directement depuis votre carte graphique sans message UAC.
echo.
powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c net localgroup \"Utilisateurs du journal de performances\" %USERNAME% /add & net localgroup \"Performance Log Users\" %USERNAME% /add & echo. & echo [SUCCES] Compte ajoute avec succes ! & echo. & echo VEUILLEZ VOUS DECONNECTER DE WINDOWS (OU REDEMARRER) POUR APPLIQUER LE DROIT. & echo. & pause' -Verb RunAs"
exit /b 0
