@echo off
title OmniLaunch Gamer Edition
cd /d "%~dp0"

:: Elevate to Administrator for hardware ETW FPS capture
net session >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

if exist "%~dp0OmniLaunch.exe" (
    start "" "%~dp0OmniLaunch.exe"
    exit /b
)

where pythonw >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    start "" pythonw "%~dp0..\dev\main.py"
) else (
    start "" python "%~dp0..\dev\main.py"
)
exit /b
