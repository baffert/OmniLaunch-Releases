@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

set "APP_VER=v1.2.0"
if exist "%~dp0VERSION.txt" (
    set /p APP_VER=<"%~dp0VERSION.txt"
)

title OmniLaunch Gamer Edition %APP_VER%
echo ==============================================================
echo       OMNILAUNCH GAMER EDITION - %APP_VER%
echo ==============================================================
echo.

set "OL_DIR=%~dp0"
if "%OL_DIR:~-1%"=="\" set "OL_DIR=%OL_DIR:~0,-1%"
set "OL_EXE=%OL_DIR%\OmniLaunch.exe"

if not exist "%OL_EXE%" (
    echo [ERREUR] OmniLaunch.exe est introuvable dans ce dossier.
    pause
    exit /b 1
)

start "" /D "%OL_DIR%" "%OL_EXE%"
exit /b 0
