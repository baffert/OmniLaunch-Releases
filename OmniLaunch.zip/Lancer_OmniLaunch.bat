@echo off
setlocal
cd /d "%~dp0"
title OmniLaunch Gamer Edition v1.1.0 (Build 10)
echo ==============================================================
echo       OMNILAUNCH GAMER EDITION - v1.1.0 (Build 10)
echo ==============================================================
echo.

set "OL_DIR=%~dp0"
if "%OL_DIR:~-1%"=="\" set "OL_DIR=%OL_DIR:~0,-1%"
set "OL_EXE=%OL_DIR%\OmniLaunch.exe"

if not exist "%OL_EXE%" (
    echo [ERREUR] OmniLaunch.exe est introuvable dans ce dossier.
    pause
    exit /b 1
)

start "" /D "%OL_DIR%" "%OL_EXE%"
exit /b 0
