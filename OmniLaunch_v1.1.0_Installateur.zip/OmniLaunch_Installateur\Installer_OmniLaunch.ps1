# Assistant de deploiement moderne OmniLaunch Gamer Edition
param(
    [switch]$Silent = $false
)

$ErrorActionPreference = "Stop"

$AppName = "OmniLaunch"
$AppVersion = "1.1.0"
$AppPublisher = "baffert"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SetupFilesDir = Join-Path $ScriptDir "Setup_Files"

if (-not (Test-Path $SetupFilesDir)) {
    Write-Host "[ERREUR] Le dossier Setup_Files est introuvable." -ForegroundColor Red
    Write-Host "Veuillez d'abord extraire l'archive ZIP complete." -ForegroundColor Yellow
    exit 1
}

$InstallDir = Join-Path $env:LOCALAPPDATA "Programs\OmniLaunch"
$ExeTarget = Join-Path $InstallDir "OmniLaunch.exe"
$IcoTarget = Join-Path $InstallDir "app.ico"
$UninstBat = Join-Path $InstallDir "Desinstaller_OmniLaunch.bat"

Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "     INSTALLATION DE OMNILAUNCH GAMER EDITION v$AppVersion     " -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Dossier d'installation : $InstallDir" -ForegroundColor Gray

# 1. Fermer toute instance precedente
Get-Process -Name "OmniLaunch" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

# 2. Deploiement des fichiers
Write-Host "[1/4] Copie des fichiers de l'application..." -ForegroundColor Yellow
if (-not (Test-Path $InstallDir)) {
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
}
Copy-Item -Path "$SetupFilesDir\*" -Destination $InstallDir -Recurse -Force

# 3. Creation des raccourcis
Write-Host "[2/4] Creation des raccourcis Bureau et Menu Demarrer..." -ForegroundColor Yellow
$WshShell = New-Object -ComObject WScript.Shell

# Raccourci Bureau
$DesktopPath = [Environment]::GetFolderPath("Desktop")
$DesktopShortcutPath = Join-Path $DesktopPath "OmniLaunch.lnk"
$Shortcut = $WshShell.CreateShortcut($DesktopShortcutPath)
$Shortcut.TargetPath = $ExeTarget
$Shortcut.WorkingDirectory = $InstallDir
if (Test-Path $IcoTarget) {
    $Shortcut.IconLocation = "$IcoTarget,0"
}
$Shortcut.Description = "OmniLaunch - Universal Game Launcher"
$Shortcut.Save()

# Raccourci Menu Demarrer
$StartMenuPath = [Environment]::GetFolderPath("Programs")
$StartShortcutPath = Join-Path $StartMenuPath "OmniLaunch.lnk"
$StartShortcut = $WshShell.CreateShortcut($StartShortcutPath)
$StartShortcut.TargetPath = $ExeTarget
$StartShortcut.WorkingDirectory = $InstallDir
if (Test-Path $IcoTarget) {
    $StartShortcut.IconLocation = "$IcoTarget,0"
}
$StartShortcut.Description = "OmniLaunch - Universal Game Launcher"
$StartShortcut.Save()

# 4. Inscription dans Windows (Ajout/Suppression de programmes)
Write-Host "[3/4] Enregistrement dans Windows (Applications & Fonctionnalites)..." -ForegroundColor Yellow
$RegPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\OmniLaunch"
if (-not (Test-Path $RegPath)) {
    New-Item -Path $RegPath -Force | Out-Null
}
Set-ItemProperty -Path $RegPath -Name "DisplayName" -Value "OmniLaunch Gamer Edition"
Set-ItemProperty -Path $RegPath -Name "DisplayVersion" -Value $AppVersion
Set-ItemProperty -Path $RegPath -Name "Publisher" -Value $AppPublisher
Set-ItemProperty -Path $RegPath -Name "InstallLocation" -Value $InstallDir
Set-ItemProperty -Path $RegPath -Name "DisplayIcon" -Value "$ExeTarget,0"
Set-ItemProperty -Path $RegPath -Name "UninstallString" -Value "`"$UninstBat`""
Set-ItemProperty -Path $RegPath -Name "NoModify" -Value 1
Set-ItemProperty -Path $RegPath -Name "NoRepair" -Value 1

Write-Host "[4/4] Installation terminee avec succes !" -ForegroundColor Green
Write-Host ""
Write-Host "==============================================================" -ForegroundColor Green
Write-Host "     OMNILAUNCH GAMER EDITION EST PRET A ETRE UTILISE !       " -ForegroundColor Green
Write-Host "==============================================================" -ForegroundColor Green
Write-Host ""

if (-not $Silent) {
    $choice = Read-Host "Souhaitez-vous lancer OmniLaunch maintenant ? (O/N) [O]"
    if ($choice -ne "N" -and $choice -ne "n") {
        Start-Process -FilePath $ExeTarget -WorkingDirectory $InstallDir
    }
}
